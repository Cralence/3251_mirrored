
# Task 7: Register your repo

Now that your team has finished most of the tasks, you have to promote it! As the **Promotion Manager**, your tasks are:

1. Look at your team's page here: `https://csci3251-2023.github.io/(repo name)` <br>Again, you should use your actual repo name!
2. Edit the page and include the repo last updated time using `site.time` at the bottom of the page (*HOW?*)
  * Note: Rendering the page takes time, be patient!
3. Go to the public repo of **`csci3251-2023.github.io`** in the *CSCI3251-2023* organization
4. Edit the `readme.md` file to add a link of your team, and request for review from @chuckjee

#### And there you're done with the group work! Hurray!
